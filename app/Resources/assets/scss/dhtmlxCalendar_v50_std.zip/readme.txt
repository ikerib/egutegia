dhtmlxCalendar v.5.0 Standard edition

(c) Dinamenta, UAB.